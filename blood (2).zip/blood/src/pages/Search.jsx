import React, { useState } from 'react';
import stateDistricts from '../data/stateDistrictData';
import '../styles/Search.css';

function Search() {
  const [donors, setDonors] = useState([]);
  const [state, setState] = useState('');
  const [district, setDistrict] = useState('');
  const [bloodGroup, setBloodGroup] = useState('');
  const [loading, setLoading] = useState(false);

  const searchDonors = async () => {
    if (!state || !district || !bloodGroup) {
      alert('Please select state, district, and blood group.');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(`http://localhost:5000/api/donors?state=${encodeURIComponent(state)}&district=${encodeURIComponent(district)}&bloodGroup=${encodeURIComponent(bloodGroup)}`);
      const data = await res.json();
      setDonors(data);
    } catch (err) {
      alert('❌ Could not fetch donors.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="search-page">
      <h2 className="search-title">Find Blood Donors</h2>

      <div className="search-form">
        <select className="search-select" value={state} onChange={(e) => {
          setState(e.target.value);
          setDistrict('');
        }}>
          <option value="">-- Select State --</option>
          {Object.keys(stateDistricts).map((st, i) => (
            <option key={i} value={st}>{st}</option>
          ))}
        </select>

        <select className="search-select" value={district} onChange={(e) => setDistrict(e.target.value)}>
          <option value="">-- Select District --</option>
          {(stateDistricts[state] || []).map((dist, i) => (
            <option key={i} value={dist}>{dist}</option>
          ))}
        </select>

        <select className="search-select" value={bloodGroup} onChange={(e) => setBloodGroup(e.target.value)}>
          <option value="">-- Select Blood Group --</option>
          <option value="A+">A+</option>
          <option value="B+">B+</option>
          <option value="O+">O+</option>
          <option value="AB+">AB+</option>
          <option value="A-">A-</option>
          <option value="B-">B-</option>
          <option value="O-">O-</option>
          <option value="AB-">AB-</option>
        </select>

        <button className="search-button" onClick={searchDonors} disabled={loading}>
          {loading ? 'Searching...' : 'Search Donors'}
        </button>
      </div>

      <div className="donor-list">
        {donors.length === 0 ? (
          <div className="no-results">No donors found.</div>
        ) : (
          donors.map((d, idx) => (
            <div key={idx} className="donor-card">
              <strong>{d.name}</strong>
              <div>Sex: {d.sex}</div>
              <div>Age: {d.age}</div>
              <div>Blood Group: {d.bloodGroup}</div>
              <div>Location: {d.state}, {d.district}</div>
              <div>Phone No: {d.contact}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default Search;
