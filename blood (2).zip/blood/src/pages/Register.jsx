import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import "../styles/Register.css";

function Register() {
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    sex: '',
    bloodGroup: '',
    state: '',
    district: '',
    contact: ''
  });

  const navigate = useNavigate();
  const userId = localStorage.getItem('userId');

  useEffect(() => {
    if (!userId) {
      navigate('/');
    }
  }, [userId, navigate]);

  const handleChange = (e) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/register-donor', { ...formData, userId });
      alert('Donor registered successfully!');
      setFormData({
        name: '',
        age: '',
        sex: '',
        bloodGroup: '',
        state: '',
        district: '',
        contact: ''
      });
    } catch (err) {
      alert('Registration failed');
    }
  };

  return (
    <div className="register-page">
      <form className="register-form" onSubmit={handleSubmit}>
        <h2 className="register-title">Donor Registration</h2>

        <label className="register-label">
          Name
          <input
            className="register-input"
            name="name"
            type="text"
            placeholder="Full Name"
            value={formData.name}
            onChange={handleChange}
            required
          />
        </label>

        <label className="register-label">
          Age
          <input
            className="register-input"
            name="age"
            type="number"
            placeholder="Age"
            value={formData.age}
            onChange={handleChange}
            required
          />
        </label>

        <label className="register-label">
          Sex
          <input
            className="register-input"
            name="sex"
            type="text"
            placeholder="e.g., male, female"
            value={formData.sex}
            onChange={handleChange}
            required
          />
        </label>

        <label className="register-label">
          Blood Group
          <input
            className="register-input"
            name="bloodGroup"
            type="text"
            placeholder="e.g., A+, B-"
            value={formData.bloodGroup}
            onChange={handleChange}
            required
          />
        </label>

        <label className="register-label">
          State
          <input
            className="register-input"
            name="state"
            type="text"
            placeholder="State"
            value={formData.state}
            onChange={handleChange}
            required
          />
        </label>

        <label className="register-label">
          District
          <input
            className="register-input"
            name="district"
            type="text"
            placeholder="District"
            value={formData.district}
            onChange={handleChange}
            required
          />
        </label>

        <label className="register-label">
          Contact
          <input
            className="register-input"
            name="contact"
            type="tel"
            placeholder="Phone Number"
            value={formData.contact}
            onChange={handleChange}
            required
          />
        </label>

        <button className="register-button" type="submit">Submit</button>
      </form>
    </div>
  );
}

export default Register;
