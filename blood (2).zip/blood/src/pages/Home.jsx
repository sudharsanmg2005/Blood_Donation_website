import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../styles/Home.css';

const Home = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const navigate = useNavigate();

  const toggleForm = () => {
    setIsLogin(!isLogin);
    setFormData({ name: '', email: '', password: '' });
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const url = isLogin ? '/api/auth/login' : '/api/auth/signup';

    try {
      const res = await axios.post(`http://localhost:5000${url}`, formData);
      localStorage.setItem('userId', res.data.user._id);
      alert(isLogin ? 'Login successful!' : 'Signup successful!');
      navigate('/dashboard');
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.message || 'Something went wrong!');
    }
  };

  return (
    <div className="home-container">
      <h2 className="home-title">
        {isLogin ? 'Login' : 'Signup'} to Blood Donation Portal
      </h2>
      <form className="home-form" onSubmit={handleSubmit}>
        {!isLogin && (
          <div className="home-field">
            <span className="home-label">Name:</span>
            <input
              className="home-input"
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>
        )}
        <div className="home-field">
          <span className="home-label">Email:</span>
          <input
            className="home-input"
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="home-field">
          <span className="home-label">Password:</span>
          <input
            className="home-input"
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>
        <button className="home-submit" type="submit">
          {isLogin ? 'Login' : 'Signup'}
        </button>
      </form>
      <p className="home-text">
        {isLogin ? "Don't have an account?" : 'Already have an account?'}{' '}
        <button className="home-toggle" onClick={toggleForm}>
          {isLogin ? 'Signup here' : 'Login here'}
        </button>
      </p>
    </div>
  );
};

export default Home;
