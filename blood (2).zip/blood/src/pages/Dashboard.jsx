import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../styles/Dashboard.css';
import { useNavigate } from 'react-router-dom';

function Dashboard() {
  const [donor, setDonor] = useState(null);
  const userId = localStorage.getItem('userId');
  const navigate = useNavigate();

  useEffect(() => {
    if (!userId) {
      navigate('/');
      return;
    }

    async function fetchDonor() {
      try {
        const res = await axios.get(`http://localhost:5000/api/donor/${userId}`);
        setDonor(res.data);
      } catch (err) {
        console.log(err);
      }
    }
    fetchDonor();
  }, [userId, navigate]);

  return (
    <div className="dashboard-container">
      <h2 className="dashboard-title">Dashboard</h2>
      {donor ? (
        <div className="dashboard-details">
          <p className="dashboard-field"><span className="dashboard-label">Name:</span> {donor.name}</p>
          <p className="dashboard-field"><span className="dashboard-label">Age:</span> {donor.age}</p>
          <p className="dashboard-field"><span className="dashboard-label">Blood Group:</span> {donor.bloodGroup}</p>
          <p className="dashboard-field"><span className="dashboard-label">State:</span> {donor.state}</p>
          <p className="dashboard-field"><span className="dashboard-label">District:</span> {donor.district}</p>
          <p className="dashboard-field"><span className="dashboard-label">Contact:</span> {donor.contact}</p>
        </div>
      ) : (
        <p className="dashboard-loading">Loading...</p>
      )}
    </div>
  );
}

export default Dashboard;
