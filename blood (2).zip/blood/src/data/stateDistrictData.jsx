const stateDistricts = {
    "Andhra Pradesh": ["Anantapur", "Chittoor", "Guntur", "Krishna", "Kurnool"],
    "Bihar": ["Patna", "Gaya", "Bhagalpur", "Muzaffarpur", "Darbhanga"],
    "Karnataka": ["Bengaluru Urban", "Mysuru", "Davanagere", "Udupi", "Ballari"],
    "Maharashtra": ["Mumbai", "Pune", "Nagpur", "Nashik", "Aurangabad"],
    "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Salem", "Tirunelveli","Trichy","Kanyakumari"],
    "Uttar Pradesh": ["Lucknow", "Kanpur", "Varanasi", "Agra", "Allahabad"]
  };
  
  export default stateDistricts;