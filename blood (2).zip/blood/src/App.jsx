import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Navigate } from 'react-router-dom';
import Home from './pages/Home';
import Register from './pages/Register';
import Search from './pages/Search';
import Dashboard from './pages/Dashboard';
import Login from './pages/Login';
import './App.css';
import bloodimage from './assets/bloodlogo.png';

const PrivateRoute = ({ children }) => {
  const userId = localStorage.getItem('userId');
  return userId ? children : <Navigate to="/" />;
};

function App() {
  const userId = localStorage.getItem('userId');

  const handleLogout = () => {
    localStorage.removeItem('userId');
    window.location.href = '/';
  };

  return (
    <Router>
      <div className="navbar">
        <div className="logo">
          <img src={bloodimage} alt="logo" />
        </div>
        <nav>
          <Link to="/">Home</Link>
          <Link to="/search">Search</Link>
          {userId && <Link to="/register">Register</Link>}
          {/* {userId && <Link to="/dashboard">Dashboard</Link>} */}
         
        </nav>
      </div>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/search" element={<Search />} />
        <Route
          path="/register"
          element={
            <PrivateRoute>
              <Register />
            </PrivateRoute>
          }
        />
        {/* <Route
          path="/dashboard"
          element={
            <PrivateRoute>
              <Dashboard />
            </PrivateRoute>
          } */}
        {/* /> */}
      </Routes>
    </Router>
  );
}

export default App;
